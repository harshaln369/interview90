// import logo from './logo.svg';
import "./App.css";
import { Routes, Route } from "react-router-dom";
import ErrorPage from "./pages/ErrorPage/ErrorPage.component";
import Header from "./components/Header/Header.component";
import LoginPage from "./pages/LoginPage/LoginPage.component";
import MoviesPage from "./pages/MoviesPage/MoviesPage.component";
import MoviesDetailPage from "./pages/MoviesDetailPage/MoviesDetailPage.component";

function App() {
  return (
    <Routes>
      <Route element={<Header />}>
        <Route index element={<LoginPage />} />
        <Route path="movies" element={<MoviesPage />} />
        <Route path="movies/:id" element={<MoviesDetailPage />} />
        <Route path="*" element={<ErrorPage />} />
      </Route>
    </Routes>
  );
}

export default App;
