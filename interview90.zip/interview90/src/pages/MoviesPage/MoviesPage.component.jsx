import React, { useState } from "react";
import { searchMovies } from "../../api/api";
import Loader from "../../components/Loader/Loader.component";
import MoviesList from "../../components/MoviesList/MoviesList.component";
import classes from "./moviesPage.module.css";

const MoviesPage = () => {
  const [movies, setMovies] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleSearch = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const movies = await searchMovies(searchTerm);
      if (movies.Response === "True") {
        setError(null);
        setMovies(movies.Search);
      } else {
        setError(movies.Error);
        setMovies([]);
      }
      setLoading(false);
    } catch (err) {
      setError(err.message);
      setMovies([]);
      setLoading(false);
    }
  };

  const handleSearchChange = (e) => {
    setSearchTerm(e.target.value);
  };

  return (
    <form onSubmit={handleSearch} className={classes.movieContainer}>
      <h1>Search Movies</h1>
      <input
        className={classes.searchInput}
        type="search"
        name="searchmovies"
        value={searchTerm}
        onChange={handleSearchChange}
      />

      <button type="submit" className={classes.searchButton}>
        Search
      </button>
      {error && <h5>{error} Please Search Again</h5>}

      <MoviesList list={movies} />

      {loading && <Loader />}
    </form>
  );
};

export default MoviesPage;
