import React, { useEffect, useState } from "react";
import { loginUser } from "../../api/api";
import { useNavigate } from "react-router-dom";
import Loader from "../../components/Loader/Loader.component";
import classes from "./loginPage.module.css";

const LoginPage = () => {
  const [inputs, setInputs] = useState({ username: "", password: "" });
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      navigate("/movies");
    }
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const loginData = await loginUser(inputs);

      if (loginData.error) {
        setError(loginData.data.validationError.toString());
        setLoading(false);
      } else {
        setLoading(false);
        localStorage.setItem("token", loginData.token);
        navigate("/movies");
      }
    } catch (err) {
      setError(err.message);
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    setInputs({ ...inputs, [e.target.name]: e.target.value });
  };

  return (
    <div className={classes.loginContainer}>
      <h1>Log in</h1>
      <form onSubmit={handleSubmit} className={classes.form}>
        <div className={classes.inputContainer}>
          <label htmlFor="username" className={classes.label}>
            Username:{" "}
          </label>
          <input
            className={classes.input}
            id="username"
            type="text"
            name="username"
            value={inputs.username}
            onChange={handleChange}
          />
        </div>

        <div className={classes.inputContainer}>
          <label htmlFor="password" className={classes.label}>
            Password:{" "}
          </label>
          <input
            className={classes.input}
            id="password"
            type="password"
            name="password"
            value={inputs.password}
            onChange={handleChange}
          />
        </div>

        <button className={classes.button} type="submit">
          Login
        </button>
      </form>
      {error && <h5>{error} Please try again.</h5>}

      {loading && <Loader />}
    </div>
  );
};

export default LoginPage;
