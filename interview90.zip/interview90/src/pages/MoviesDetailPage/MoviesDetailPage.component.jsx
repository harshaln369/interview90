import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { getMovieDetails } from "../../api/api";
import Loader from "../../components/Loader/Loader.component";
import classes from "./moviesDetail.module.css";

const MoviesDetailPage = () => {
  const { id } = useParams();

  const [movieDetails, setMovieDetails] = useState({});
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMovieDetails = async (id) => {
      try {
        const movieDetails = await getMovieDetails(id);

        if (movieDetails.Response === "True") {
          setMovieDetails(movieDetails);
        } else {
          setError(movieDetails.Error);
          setMovieDetails({});
        }
        setLoading(false);
      } catch (err) {
        setError(err.message);
        setLoading(false);
      }
    };
    fetchMovieDetails(id);
  }, [id]);
  return (
    <div className={classes.movieDetailsContainer}>
      {Object.keys(movieDetails).length > 0 && (
        <>
          <h2 className={classes.movieTitle}>{movieDetails.Title}</h2>
          <img src={movieDetails.Poster} alt={movieDetails.Title} />
          <p>
            IMDB:{" "}
            <span className={classes.imdb}>{movieDetails.imdbRating}</span>
          </p>
          <p>{movieDetails.Plot}</p>
        </>
      )}
      {error && <h5>{error}</h5>}

      {loading && <Loader />}
    </div>
  );
};

export default MoviesDetailPage;
