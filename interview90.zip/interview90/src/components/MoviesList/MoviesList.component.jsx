import React from "react";
import { useNavigate } from "react-router-dom";
import classes from "./moviesList.module.css";

const MoviesList = ({ list }) => {
  const navigate = useNavigate();
  return (
    <ul className={classes.listUl}>
      {list.length > 0 &&
        list.map((movie) => {
          return (
            <li
              className={classes.listLi}
              key={movie.imdbID}
              onClick={() => navigate(`/movies/${movie.imdbID}`)}
            >
              <h5>{movie.Title}</h5>
              <p>{movie.Year}</p>
            </li>
          );
        })}
    </ul>
  );
};

export default MoviesList;
