import axios from "axios";

export const loginUser = async ({ username, password }) => {
  try {
    const { data } = await axios.post(process.env.REACT_APP_LOGIN_URL, {
      username,
      password,
    });

    return data;
  } catch (err) {
    return err.response.data;
  }
};

export const searchMovies = async (searchTerm) => {
  try {
    const { data } = await axios.get(
      `http://www.omdbapi.com/?apikey=${process.env.REACT_APP_API_KEY}&type=movie&s=${searchTerm}`
    );
    return data;
  } catch (err) {
    return err.response;
  }
};

export const getMovieDetails = async (id) => {
  try {
    const { data } = await axios.get(
      `http://www.omdbapi.com/?apikey=${process.env.REACT_APP_API_KEY}&i=${id}`
    );
    return data;
  } catch (err) {
    return err.response;
  }
};
